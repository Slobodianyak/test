package com.softserveinc.edu.oms.web.util;

public class StringWrapper {
	private String string;

	public StringWrapper() {

	}

	public String getString() {
		return string;
	}

	public void setString(final String string) {
		this.string = string;
	}
}
